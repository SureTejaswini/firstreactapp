export const INITIALIZE = 'INITIALIZE';
export const ADD_ISSUE = 'ADD_ISSUE';